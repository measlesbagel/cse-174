/*
Name: Myles Cagle
Date: 9/3/2019
Section: C
Description: Prints out text that looks like a bunny
*/

public class Bunny {

  public static void main(String[] arg) {
    System.out.println("(\\(\\");
    System.out.println("( -.-)");
    System.out.println("o_(\")(\")");
  }
}
