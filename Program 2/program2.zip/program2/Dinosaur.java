/*
Name: Myles Cagle
Date: 9/3/2019
Section: C
Description: Prints out text that looks like a dinosaur
*/

public class Dinosaur {

  public static void main(String[] arg) {
    System.out.println("        __");
    System.out.println("       /..\\_");
    System.out.println("      /     \\");
    System.out.println("  _   \\ `___/ _");
    System.out.println(" / \\   | |   / \\");
    System.out.println("-   ----  ---   --");
    System.out.println(" \\ /         \\ /");
  }
}
