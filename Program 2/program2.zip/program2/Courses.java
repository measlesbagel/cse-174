/*
Name: Myles Cagle
Date: 9/3/2019
Section: C
Description: Prints out text that shows my course list
*/

public class Courses {

  public static void main(String[] arg) {
    System.out.println("Course     Instructor    Credits");
    System.out.println("------------------------------");
    System.out.println("CSE174     Mohamed       3");
    System.out.println("CSE262     Cross         3");
    System.out.println("GEO201     Prytherch     3");
    System.out.println("ISA387     Havelka       3");
    System.out.println("BLS342     McCown        3");
  }
}
